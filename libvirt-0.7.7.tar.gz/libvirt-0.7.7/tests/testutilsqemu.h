
#include "capabilities.h"

virCapsPtr testQemuCapsInit(void);
